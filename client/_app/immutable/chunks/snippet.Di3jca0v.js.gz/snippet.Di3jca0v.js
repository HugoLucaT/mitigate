import{l as r,E as a,n as i,q as p}from"./runtime.BrGAlQLE.js";function c(t,f,...n){var e,s;r(()=>{e!==(e=t())&&(s&&(p(s),s=null),e&&(s=i(()=>e(f,...n))))},a)}export{c as s};
