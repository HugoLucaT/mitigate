import{a as t}from"../chunks/entry.DWOIv9A9.js";export{t as start};
